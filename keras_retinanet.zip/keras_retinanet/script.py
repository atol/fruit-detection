# -*- coding: utf-8 -*-
"""
Created on Thu Apr 16 03:11:08 2020

@author: natch
"""

# Running directly from the repository:
keras_retinanet/bin/train.py csv /path/to/csv/file/containing/annotations /../../OID/csv_folder/train-annotation-bbox.csv