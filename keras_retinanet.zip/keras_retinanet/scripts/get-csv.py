"""
Gets annotation for all labels and write to a csv file
"""

sets = ["train", "test", "validation"]
fruits = ["Apple", "Banana", "Orange"]

import os
import sys
import argparse

parser = argparse.ArgumentParser()
parser.add_argument(dest="dataset", default="train", type=str)

args = parser.parse_args()


for st in sets:
    for fruit in fruits:

        txt_files = []

        path = args.dataset + "/" + st + "/" + fruit + "/Label/"

        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                with open(path + filename) as f:
                    for line in f:
                        line = line.split()
                        className, xMin, yMin, xMax, yMax = [str(s) for s in line]
                        csvRow = path[:-6] + filename[:-4] + ".jpg," + xMin.split('.')[0] + "," + yMin.split('.')[0] + "," + xMax.split('.')[0] + "," + yMax.split('.')[0] + "," + className
                        txt_files.append(csvRow)    # appends line in file to csv

        result = "/csv-folder/"

        if path.find(st):
            result += st + '-'
        else:
            sys.exit("Invalid path to data type")

        if path.find(fruit):
            result += fruit.lower()
        else:
            sys.exit("Invalid path to fruit type")

        result += ".csv"

        with open(result, "w") as outfile:
            for txt in txt_files:
                outfile.write(txt)
                outfile.write("\n")